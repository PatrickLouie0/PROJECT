 <nav class="sidebar">
         <div class="text">

      <div class="btn" id="btn">
         <i class="fa fa-times" aria-hidden="true"></i>
      </div>
      <p>Sales&Inventory</p>
         </div>
         <ul>

            <li><a href="viewproduct.php">VIEW PRODUCT</a></li>
            <li><a href="check_stock.php">CHECK STOCK</a></li>       
            <li><a href="user_profile.php">ACCOUNT</a></li>
            <li><a href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>