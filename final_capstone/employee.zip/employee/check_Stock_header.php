 <nav class="sidebar">
         <div class="text">

      <div class="btn" id="btn">
         <i class="fa fa-times" aria-hidden="true"></i>
      </div>
      <p style="color: white">Sales&Inventory</p>
         </div>
         <ul>

            <li><a href="viewproduct.php">VIEW PRODUCT</a></li>
            <li><a href="check_stock.php">CHECK STOCK</a></li>       
            <li><a href="user_profile.php">ACCOUNT</a></li>
            <li><a href="logout.php">LOGOUT</a></li>
         </ul>
      </nav>
<!--sidebar-->
   <header>
    <div class="btn" id="btns">
         <i class="fa fa-bars"  ></i>

      </div>
       <p style="color: white;font-size: 25px; font-weight: bold;padding: 8px;" ><?php include("../php/store_name.php")?></p>
	</header>