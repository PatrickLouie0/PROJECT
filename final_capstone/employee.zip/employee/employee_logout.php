<?php 
	require_once('store.php');
	header("location:login.php");
 	?>